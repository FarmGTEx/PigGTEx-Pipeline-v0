###################################################################################
###################                 run TWAS                    ###################
###################################################################################

#################
#SPrediXcan
TWAS_SPrediXcan_pipeline_V1.sh

Note:The required summary data needs to be preprocessed. See pipeline for details.

#################
#SMulTiXcan
TWAS_SMulTiXcan_pipeline_V1.sh

Note:The covariate files required by the software need to be processed separately. See the 11th script in the makeModels folder for details.